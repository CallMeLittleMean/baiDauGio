package com.example.baitaptrenlop;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {  // sửa class thành public

    TextView luckyNumberText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        luckyNumberText = findViewById(R.id.luckyNumberText);

        // Nhận dữ liệu từ Intent
        int luckyNumber = getIntent().getIntExtra("LUCKY_NUMBER", 0);

        // Hiển thị số may mắn
        luckyNumberText.setText(String.valueOf(luckyNumber));
    }
}
