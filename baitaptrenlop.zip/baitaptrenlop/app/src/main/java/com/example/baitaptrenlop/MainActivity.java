package com.example.baitaptrenlop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button wishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wishButton = findViewById(R.id.wishButton);

        wishButton.setOnClickListener(v -> {
            // Sinh số may mắn ngẫu nhiên từ 1 đến 999
            int luckyNumber = new Random().nextInt(999) + 1;

            // Tạo intent và truyền dữ liệu
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("LUCKY_NUMBER", luckyNumber);
            startActivity(intent);
        });
    }
}
